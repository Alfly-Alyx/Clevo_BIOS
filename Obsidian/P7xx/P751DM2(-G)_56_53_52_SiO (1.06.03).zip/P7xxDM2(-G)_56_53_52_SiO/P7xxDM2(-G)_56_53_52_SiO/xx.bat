ELASH15 eP7xxDM2.53 /I /AD /F2 /M /P
call xxx.bat