fpt -f P7xxDM2.56 -me
Call xx.bat