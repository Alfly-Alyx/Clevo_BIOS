@echo off
echo.
echo.
echo   ***********************************************************
echo   This is to update the system BIOS for OBSIDIAN-PC P751DM2(-G) series to: 
echo.
echo   BIOS V1.05.06
echo   EC   V1.05.03
echo   EC2  V1.05.02
echo.
echo   Please make sure you have the right model of computer.
echo   (If this firmware is applied to a non-OBSIDIAN-PC P775DM3(-G) model,
echo    the computer may be non-operative.)
echo.
echo.
echo   Please make sure the computer is on AC power.
echo.
echo   The system will automatically shut down after the process is finished.
echo   Press any key to continue or press "Ctrl" + "C" to quit.
echo.
echo   ***********************************************************
pause
afudos P7xxDM2.56 /E /P /B /N /X
x.bat