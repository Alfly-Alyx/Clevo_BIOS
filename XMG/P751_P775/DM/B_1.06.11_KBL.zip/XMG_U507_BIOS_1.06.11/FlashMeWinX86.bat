@@echo off

@set BIOS.ROM=P7xxDM2.BIN
@set BIOS.ROM2=P7xxDM2.rom

REM call install

REM :: Flash ME
REM :: Save MAC, EeupdateW64 only intel lan need use
REM @if exist MAC.TXT del MAC.TXT    
REM EeupdateW64 /NIC=1 /MAC_DUMP_FILE

fptW -f %BIOS.ROM% -l 0x200000 -y
if errorlevel 1 goto End

REM EEUPDATEW64 /NIC=1 /A MAC.TXT

AFUwin.exe %BIOS.ROM2% /p /b /n  /x /shutdown 
