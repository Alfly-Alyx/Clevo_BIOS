@@echo off

@set BIOS.ROM=P7xxDM2.BIN
@set BIOS.ROM2=P7xxDM2.rom

rem call install

rem :: Flash ME
rem :: Save MAC, EeupdateW64 only intel lan need use
rem @if exist MAC.TXT del MAC.TXT    
rem EeupdateW64 /NIC=1 /MAC_DUMP_FILE

fptW64 -f %BIOS.ROM% -l 0x200000 -y
if errorlevel 1 goto End

rem EEUPDATEW64 /NIC=1 /A MAC.TXT

AFUwinx64.exe %BIOS.ROM2% /p /b /n /x  /shutdown 
