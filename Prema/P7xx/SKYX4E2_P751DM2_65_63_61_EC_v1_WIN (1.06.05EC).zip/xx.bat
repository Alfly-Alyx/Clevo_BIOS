D eX4E2.EC -h -u -s
call xxx.bat
