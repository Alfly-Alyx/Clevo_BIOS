C -f SKYX4E2.EC1 -me
Call xx.bat