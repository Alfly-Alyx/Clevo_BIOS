B SKYX4E2.EC1 /E /P /B /N
call x.bat

