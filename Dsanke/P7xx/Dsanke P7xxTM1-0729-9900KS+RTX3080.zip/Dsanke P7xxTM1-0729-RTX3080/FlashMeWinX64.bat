@echo off
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting administrative privileges...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
echo Set UAC = CreateObject("Shell.Application") > "%temp%\getadmin.vbs"
echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
"%temp%\getadmin.vbs"
exit /B

:gotAdmin
if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
pushd "%CD%"
CD /D "%~dp0"
cls

echo          -------------------------------------
echo.
echo                  Clevo P7xxTM1(G) BIOS
echo.
echo          -------------------------------------
echo.
echo Continuing, you begin the process of BIOS flashing.
echo.
pause

rem ======================================================================
rem Choice Menu
rem ======================================================================

:start
cls
echo [Clevo P7xxTM1(G) BIOS SOP]
echo Make sure the AC adaptor is plugged in.
echo.
echo 1. Run WMESET.exe  (Unlock Intel ME)
echo 2. Run FLASH       (Flash BIOS)
echo 3. Cancel
echo.
echo Make your choice by entering a number.
echo.
CHOICE /C:123 /N

IF %ERRORLEVEL% EQU 1 goto MESET
IF %ERRORLEVEL% EQU 2 goto FLASH
IF %ERRORLEVEL% EQU 3 goto end

rem ======================================================================
rem Intel ME unlock
rem ======================================================================

:MESET
cls
echo This will unlock Intel ME.
echo.
pause
WMeset.exe
echo.
echo WMESET step completed. The system may cold boot automatically.
echo.
pause
goto end

rem ======================================================================
rem BIOS Flashing
rem ======================================================================

:FLASH
cls
echo This will flash BIOS version R1.07.29.
echo.
pause

echo Starting first flash step (Intel FPT)...
pause
fptW64.exe -f BIOS.ROM -l 0x200000 -y
if errorlevel 1 goto error

echo.
echo FPT flash step completed successfully.
pause

echo Starting second flash step (AFUWINx64)...
pause
AFUwinx64.exe BIOS.ROM /p /b /n /r /rlc:f

echo.
echo BIOS flash process complete!
pause
goto end

rem ======================================================================
rem Error handler
rem ======================================================================

:error
echo.
echo Error!
echo Failed at flashing ME BIOS part.
echo Probably WMeset.exe wasn't executed.
pause
goto end

:end
echo.
echo Process finished.
pause
exit
