@echo
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
echo Requesting administrative privileges...
goto UACPrompt
) else ( goto gotAdmin )
:UACPrompt
echo Set UAC = CreateObject("Shell.Application") > "%temp%\getadmin.vbs"
echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
"%temp%\getadmin.vbs"
exit /B
:gotAdmin
if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
pushd "%CD%"
CD /D "%~dp0"
@echo off
cls

	echo          -------------------------------------
	echo.
	echo                  Clevo P7xxTM1(G) BIOS
	echo.
	echo          -------------------------------------
	echo.
	echo Continuing, you begin the process of BIOS flashing.
	echo.
	pause
@rem======================================================================
@rem
@rem  Choice.
@rem
@rem======================================================================
:start
cls
echo [Clevo P7xxTM1(G) BIOS SOP]
echo Make sure plugin AC adaptor.
echo 1. Run WMESET.exe, the system will auto cold boot.
echo 2. Run FLASH.
echo The CMD window display flash complete message after flash success.
echo.
echo 1. WMESET.EXE & echo 2. FLASH & echo 3. Cancel
echo Make your choice by entering a number.
echo.
CHOICE /C:123 /N
IF %ERRORLEVEL% EQU 1 goto MESET
IF %ERRORLEVEL% EQU 2 goto FLASH
IF %ERRORLEVEL% EQU 3 goto end
rem======================================================================
rem
rem  Flashing.
rem
rem======================================================================

:MESET
cls
echo This will unlock Intel ME.
echo.
pause
WMeset.exe
goto end

:FLASH
cls
echo This will flash R1.07.29 BIOS.
echo.
pause
fptW64.exe -f BIOS.ROM -l 0x200000 -y
if errorlevel 1 goto error
AFUwinx64.exe BIOS.ROM /p /b /n /r /rlc:f
:end
pause
exit
:error
echo.
pause
echo Error!
echo Failed at flashing ME BIOS part.
echo Probably WMeset.exe wasn't executed.
pause