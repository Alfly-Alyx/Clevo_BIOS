@echo
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
echo Requesting administrative privileges...
goto UACPrompt
) else ( goto gotAdmin )
:UACPrompt
echo Set UAC = CreateObject("Shell.Application") > "%temp%\getadmin.vbs"
echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
"%temp%\getadmin.vbs"
exit /B
:gotAdmin
if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
pushd "%CD%"
CD /D "%~dp0"
@echo off
cls

	echo          -------------------------------------
	echo.
	echo                  Clevo P7xxTM1(G) BIOS
	echo.
	echo          -------------------------------------
	echo.
	echo Continuing, you begin the process of BIOS flashing.
	echo.
	pause
@rem======================================================================
@rem
@rem  Choice.
@rem
@rem======================================================================
:start
cls
echo [Clevo P7xxTM1(G) BIOS SOP]
echo Make sure plugin AC adaptor.
echo 1. Run WMESET.exe, the system will auto cold boot.
echo 2. Run Backup.
echo The CMD window display flash complete message after flash success.
echo.
echo 1. WMESET.EXE & echo 2. FLASH & echo 3. Cancel
echo Make your choice by entering a number.
echo.
CHOICE /C:123 /N
IF %ERRORLEVEL% EQU 1 goto MESET
IF %ERRORLEVEL% EQU 2 goto FLASH
IF %ERRORLEVEL% EQU 3 goto end
rem======================================================================
rem
rem  Flashing.
rem
rem======================================================================

:MESET
cls
echo This will unlock Intel ME.
echo.
pause
WMeset.exe
goto end

:FLASH
cls
echo This will backup your bios as dump-bios.rom.
echo.
pause
fptW64.exe -d dump-bios.rom
:end
exit